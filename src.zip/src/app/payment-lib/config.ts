export const config = {
  'currency': 'SAR',
  'timeout': '15',
  'terminalId': 'autotech',
  'password': 'autotech@URWAY_123',
  'key': 'bc84a466dc6a52fe263cf5b81116c46af608f4652b91dad94455604c4becc49e',
 // 'requestUrl': 'http://www.sysconprojects.com/test/testproxy.php',
  'requestUrl': 'https://payments.urway-tech.com/URWAYPGService/transaction/jsonProcess/JSONrequest',
  'responseUrl': 'http://localhost/response.html',
// 'terminalId': 'tokenter',
// 'password': 'password',
// 'key': '146c0c30025cadba9fbdf9e909b49eac1b631b4afeb56485f93d8f271a832e3a',
// //'requestUrl': 'http://www.sysconprojects.com/test/testproxy.php',
// 'requestUrl': 'https://payments-dev.urway-tech.com/URWAYPGService/transaction/jsonProcess/JSONrequest',

}
