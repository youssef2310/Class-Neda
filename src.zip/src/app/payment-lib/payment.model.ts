



export class Payment{
    country : string = 'SA';
    customerName : string = '';
    address : string = '';
    city : string = 'jeddah';
    state : string = 'jeddah';
    zip : string = '21323';
    phone : string = '';
    customerEmail : string = '';
    udf2 : string = 'http://localhost:8100';
    udf3 : string = 'en';
    trackid : string = '';
    currency : string = 'SAR';
    amount : string = '';
    action : string ='1';
    tokenOperation : string = 'A';
    cardToken : string = '';
    tokentype : string = '0'


}


