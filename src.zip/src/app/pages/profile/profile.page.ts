import { Component, OnInit } from '@angular/core';
import { TranslateConfigService } from '../../services/translate-config.service';
import { ApiService } from '../../services/api.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.page.html',
  styleUrls: ['./profile.page.scss'],
})
export class ProfilePage implements OnInit {
  lang: string = '';
  parent: any = {};
  loading: boolean = false;
  constructor(
    private translateConfigService: TranslateConfigService,
    private apiService: ApiService
  ) {}

  ngOnInit() {}

  ionViewWillEnter() {
    this.lang = this.translateConfigService.getCurrentLang();
    this.parent = JSON.parse(localStorage.getItem('parent'));
  }

  logOut() {
    this.loading = true;
    this.apiService.logout().subscribe(
      (res) => {
        this.loading = false;
      },
      (error) => {
        this.loading = false;
      }
    );
  }

  changeLanguage(lang) {
    this.apiService.sharedMethods.startLoad();
    this.apiService.updateLanguage(lang).subscribe(
      (res) => {
        this.apiService.sharedMethods.dismissLoader();
        this.translateConfigService.setLanguage(lang);
        this.lang = lang;
      },
      (error) => {
        this.apiService.sharedMethods.dismissLoader();
      }
    );
  }
}
