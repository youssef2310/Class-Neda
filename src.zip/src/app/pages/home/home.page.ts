import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../services/api.service';
import { TranslateConfigService } from '../../services/translate-config.service';
// import { FCM } from 'cordova-plugin-fcm-with-dependecy-updated/ionic/ngx';
import { Platform } from '@ionic/angular';
import { DatePipe } from '@angular/common';
import { Payment } from '../../payment-lib/payment.model';
import { PaymentService } from '../../services/payment.service';
// import * as _ from 'lodash';
@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
})
export class HomePage implements OnInit {
  lang: string = '';
  parentList: any[] = [];
  parentData: any;
  notifications: any[] = [];
  notifiCount: number = 0;
  paymentDate: Payment = new Payment();
  intervalTimer;
  parentTemp: any[] = [];
  constructor(
    private translateConfig: TranslateConfigService,
    private apiService: ApiService,
    private platform: Platform,
    private datepipe: DatePipe,
    private paymentService: PaymentService
  ) {
    this.lang = this.translateConfig.getCurrentLang();
    // this.ionViewWillEnter();
    this.apiService.fireParentObs.subscribe((res) => {
      this.fillParentChildren();
    });
  }

  ngOnInit() {}

  fillParentChildren(observe?: boolean) {
    this.parentData = undefined;
    this.parentList = [];
    this.apiService.sharedMethods.startLoad();
    this.apiService.getParentChildren(observe).subscribe(
      (res: any) => {
        this.apiService.sharedMethods.dismissLoader();
        if (!res || !res.result) return;
        this.notifications = res['parent']['notifications'];
        if (this.notifications && this.notifications.length) {
          this.notifiCount = this.notifications.length;
          this.notifications.forEach((e, i) => {
            if (e.read == true) this.notifiCount -= 1;
          });
          localStorage.setItem('notifiCount', String(this.notifiCount));
        }

        // this.parentList.push(res?.result);
        this.parentData = res?.parent;
        localStorage.setItem('parent', JSON.stringify(this.parentData));
        // console.log(this.parentData);
        // console.log(this.parentList);
        this.parentList = [];
        Object.keys(res?.result).forEach((key) =>
          this.parentList.push(res?.result[key])
        );
        console.log(this.parentList);
        if (!this.parentTemp.length) this.parentTemp = this.parentList;
        //this.notifySchool();
        this.checkPaymentStatus(this.parentList);
      },
      (error) => {
        this.apiService.sharedMethods.dismissLoader();
      }
    );
  }

  ionViewWillEnter() {
    this.fillParentChildren();

    this.intervalTimer = setInterval(() => {
      this.apiService.getParentChildren().subscribe(
        (res: any) => {
          if (!res || !res.result) return;
          this.notifications = res['parent']['notifications'];
          if (this.notifications && this.notifications.length) {
            this.notifiCount = this.notifications.length;
            this.notifications.forEach((e, i) => {
              if (e.read == true) this.notifiCount -= 1;
            });
            localStorage.setItem('notifiCount', String(this.notifiCount));

            //this.notifiCount = Number(this.notifications.length);
          }


          // this.parentList.push(res?.result);
          this.parentData = res?.parent;
          localStorage.setItem('parent', JSON.stringify(this.parentData));
          // console.log(this.parentData);
          // console.log(this.parentList);
          this.parentList = [];
          Object.keys(res?.result).forEach((key) =>
            this.parentList.push(res?.result[key])
          );
          // console.log(this.parentList);
        },
        (error) => {}
      );
    }, 10000);
  }

  doRefresh(event) {
    setTimeout(() => {
      this.fillParentChildren();
      event.target.complete();
    }, 2000);
  }

  callStudent(student, school) {
    if (!student) return;

    if (
      student.call_student == 'register' ||
      (!student.paid && Number(school.school.fees) > 0)
    ) {
      this.translateConfig.translate
        .get('uhavetopaythecostoftheservice')
        .subscribe((res) => {
          this.apiService.sharedMethods.presentToast(res, 'danger');
        });
      this.getReadyToPay(student, school);
      return;
    }
    this.apiService
      .callStudent(
        student.school,
        student.parent,
        student.code,
        this.getCurrentDate(),
        false
      )
      .subscribe((res: any) => {
        if (res.status_code == 1) {
          student.call_student = 'disable';
        }
        // student.
      });
  }

  notifySchool() {
    for (let obj of this.parentList) {
      if (obj.school.start_call === true) {
        for (let student of obj.students) {
          if (student.call_student == 'enable' && student.paid == true) {
            this.getReady(student);
          }
        }
      }
    }
  }

  checkPaymentStatus(list) {
    for (let obj of list) {
      if (obj.school.fees === 0) {
        console.log('true');
        for (let student of obj.students) {
          if (student.paid == false) {
            this.setPaidProperty(student.code);
          }
        }
      }
    }
  }

  setPaidProperty(code) {
    this.apiService.updatePaymentStatus(code).subscribe((res) => {
      this.fillParentChildren();
    });
  }

  getReady(student) {
    this.apiService
      .callStudent(
        student.school,
        student.parent,
        student.code,
        this.getCurrentDate(),
        true
      )
      .subscribe((res: any) => {
        // student.
      });
  }

  getCurrentDate() {
    let date: Date = new Date();
    let latestDate = this.datepipe.transform(date, 'yyyy-MM-dd');
    return String(latestDate);
  }

  checkPayment(fees, paid) {
    console.log(fees, paid);
    if (paid == false && Number(fees) > 0) return false;
    else return true;
  }

  getReadyToPay(student, school) {
    localStorage.setItem('studentCode', student.code);

    console.log(school);
    let customerName = JSON.parse(localStorage.getItem('parent')).name;
    console.log(customerName);
    this.paymentDate.address = school.school.name;
    this.paymentDate.customerName = customerName;
    this.paymentDate.trackid = 'en'
    this.paymentDate.customerEmail =
      localStorage.getItem('mobile') + '@autotech.sa';
    this.paymentDate.phone = localStorage.getItem('mobile');
    this.paymentDate.amount = school.school.fees;
    console.log(this.paymentDate);
    this.paymentService.makePaymentService(JSON.stringify(this.paymentDate)).then(res => {
      console.log(res);
    }, error => {
      console.log(error)
    })
  }

  // checkPaymentSuccess() {
  //   this.paymentService.paymentStatusObs.subscribe((res) => {
  //     if (res == true && localStorage.getItem('studentCode')) {
  //       this.apiService
  //         .updatePaymentStatus(localStorage.getItem('studentCode'))
  //         .subscribe((res) => {
  //           this.fillParentChildren();
  //         });
  //     }
  //   });
  // }

  ionViewWillLeave() {
    if (this.intervalTimer) clearInterval(this.intervalTimer);
  }

  // onSchoolObjectChanged() {
  //   this.parentList.forEach((e, i) => {
  //     this.parentTemp.forEach((tempEle, tempIndex) => {
       
  //       if (tempIndex === i) {
  //         if (!_.isEqual(tempEle.school, e.school)) {
  //           console.log('notify');
  //          // this.notifySchool();
  //         }
  //       }
  //     });
  //   });
  // }
}
