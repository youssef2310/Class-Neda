import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApiService } from '../../services/api.service';
import { TranslateConfigService } from '../../services/translate-config.service';

@Component({
  selector: 'app-verification-code',
  templateUrl: './verification-code.page.html',
  styleUrls: ['./verification-code.page.scss'],
})
export class VerificationCodePage implements OnInit {
  lang: string = '';
  code: string = '';
  loading: boolean = false;
  constructor(
    private translateConfig: TranslateConfigService,
    private apiService: ApiService,
    private router: Router
  ) {
    this.lang = this.translateConfig.getCurrentLang();
  }

  ngOnInit() {}

  verifyCode() {
    if (!this.code.match(/^\d+$/)) {
      let msg: string = '';
      // if (this.lang == 'en') msg = 'Please enter the numbers in english';
      // else msg = 'يرجي ادخال الارقام باللغه الانجليزيه';
      // this.apiService.sharedMethods.presentToast(msg, 'danger');
      //  this.translateConfig.translate.get(
      //   'pleaseenterthenumbersinenglish'
      // ).subscribe(msg => {
      //   this.apiService.sharedMethods.presentToast(msg, 'danger');

      // })
      return;
    }

    this.loading = true;

    this.apiService.sharedVariables.verifyCode
      .confirm(this.code)
      .then((res) => {
        // this.loading = false;
        console.log(res);
        if (res && res.user) {
          let staticCode = localStorage.getItem('smsCode');

          this.apiService.verifyCode(staticCode).subscribe(
            (res) => {
              //console.log(res)
              this.loading = false;

              //this.router.navigate(['/tabs/home']);
            },
            (error) => {
              this.loading = false;
            }
          );
        }
      })
      .catch((err) => {
        this.loading = false;
        console.log(err.message);
        this.apiService.sharedMethods.presentToast(err.message, 'danger');
      });

    // this.loading = true;
  }

  onCodeChanged(code: string) {
    console.log(code);
  }

  // this called only if user entered full code
  onCodeCompleted(code: string) {
    console.log(code);
    this.code = code;
    if (this.code.length == 6) this.verifyCode();
  }
}
