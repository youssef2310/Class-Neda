export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: 'AIzaSyBpBg3ITHCAyx51bEEfjEV0V7SUKi1hLic',
    authDomain: 'auto-neda.firebaseapp.com',
    projectId: 'auto-neda',
    storageBucket: 'auto-neda.appspot.com',
    messagingSenderId: '983437943168',
    appId: '1:983437943168:web:3c070df5a1e56480296165',
    measurementId: 'G-HPE69MKVWX',
  },
};
